import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";

export default function HomePage() {
  const [address, setAddress] = useState("");
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate("/result", { state: { address } });
  };

  return (
    <div className="container">
      <Card>
        <CardContent>
          <h1 className="title">지원금을 받아봐요!</h1>
          <div className="form-group">
            <Input
              placeholder="땅의 주소를 입력하세요"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
            <Button onClick={handleSubmit}>확인하기</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
